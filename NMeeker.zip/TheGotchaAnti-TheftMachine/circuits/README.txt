LAB #3

@authors:
Kyle Krueger
Noah Meeker

Folder containing the circuits used to create the parts needed for the final schematic.
